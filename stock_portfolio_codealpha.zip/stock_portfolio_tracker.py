import csv

STOCK_PRICES = {
    "AAPL": 189.30,
    "TSLA": 248.50,
    "GOOGL": 175.60,
    "MSFT": 415.20,
    "AMZN": 192.40,
    "META": 511.90,
    "NVDA": 875.40,
    "NFLX": 628.10,
    "AMD": 172.30,
    "INTC": 31.50,
}

portfolio = {}


def show_available_stocks():
    print("\nAvailable stocks:")
    print(f"  {'Ticker':<8} {'Price (USD)':>12}")
    print("  " + "-" * 22)
    for ticker, price in STOCK_PRICES.items():
        print(f"  {ticker:<8} ${price:>11.2f}")


def add_stock():
    ticker = input("\nEnter stock ticker (e.g. AAPL): ").strip().upper()

    if ticker not in STOCK_PRICES:
        print(f"  '{ticker}' not found. Available: {', '.join(STOCK_PRICES.keys())}")
        return

    try:
        quantity = int(input(f"Enter quantity of {ticker} shares: ").strip())
        if quantity <= 0:
            print("  Quantity must be greater than 0.")
            return
    except ValueError:
        print("  Invalid quantity. Please enter a whole number.")
        return

    if ticker in portfolio:
        portfolio[ticker] += quantity
        print(f"  Updated {ticker}: now holding {portfolio[ticker]} shares.")
    else:
        portfolio[ticker] = quantity
        print(f"  Added {quantity} shares of {ticker}.")


def view_portfolio():
    if not portfolio:
        print("\n  Your portfolio is empty. Add some stocks first.")
        return

    total_value = 0.0
    print("\n" + "=" * 50)
    print(f"  {'Stock':<8} {'Price':>10} {'Qty':>6} {'Total Value':>14}")
    print("  " + "-" * 44)

    for ticker, quantity in portfolio.items():
        price = STOCK_PRICES[ticker]
        value = price * quantity
        total_value += value
        print(f"  {ticker:<8} ${price:>9.2f} {quantity:>6} ${value:>13.2f}")

    print("  " + "-" * 44)
    print(f"  {'TOTAL':>25} ${total_value:>13.2f}")
    print("=" * 50)


def save_to_csv():
    if not portfolio:
        print("\n  Portfolio is empty. Nothing to save.")
        return

    filename = "portfolio.csv"
    total_value = 0.0
    rows = []

    for ticker, quantity in portfolio.items():
        price = STOCK_PRICES[ticker]
        value = price * quantity
        total_value += value
        rows.append([ticker, f"{price:.2f}", quantity, f"{value:.2f}"])

    with open(filename, "w", newline="") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["Stock", "Price (USD)", "Quantity", "Total Value (USD)"])
        writer.writerows(rows)
        writer.writerow([])
        writer.writerow(["", "", "TOTAL", f"{total_value:.2f}"])

    print(f"\n  Portfolio saved to '{filename}' successfully.")


def remove_stock():
    if not portfolio:
        print("\n  Portfolio is empty.")
        return

    ticker = input("\nEnter ticker to remove: ").strip().upper()
    if ticker in portfolio:
        del portfolio[ticker]
        print(f"  Removed {ticker} from portfolio.")
    else:
        print(f"  {ticker} is not in your portfolio.")


def main():
    print("=" * 50)
    print("   Stock Portfolio Tracker — CodeAlpha Task 2")
    print("=" * 50)

    while True:
        print("\nMenu:")
        print("  1. View available stocks")
        print("  2. Add stock to portfolio")
        print("  3. View portfolio")
        print("  4. Remove stock from portfolio")
        print("  5. Save portfolio to CSV")
        print("  6. Exit")

        choice = input("\nChoose an option (1-6): ").strip()

        if choice == "1":
            show_available_stocks()
        elif choice == "2":
            add_stock()
        elif choice == "3":
            view_portfolio()
        elif choice == "4":
            remove_stock()
        elif choice == "5":
            save_to_csv()
        elif choice == "6":
            print("\nGoodbye!")
            break
        else:
            print("  Invalid choice. Please enter a number from 1 to 6.")


if __name__ == "__main__":
    main()
