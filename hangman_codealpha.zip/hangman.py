import random

WORDS = ["python", "hangman", "coding", "keyboard", "developer"]

HANGMAN_STAGES = [
    """
   -----
   |   |
       |
       |
       |
       |
=========
""",
    """
   -----
   |   |
   O   |
       |
       |
       |
=========
""",
    """
   -----
   |   |
   O   |
   |   |
       |
       |
=========
""",
    """
   -----
   |   |
   O   |
  /|   |
       |
       |
=========
""",
    """
   -----
   |   |
   O   |
  /|\\  |
       |
       |
=========
""",
    """
   -----
   |   |
   O   |
  /|\\  |
  /    |
       |
=========
""",
    """
   -----
   |   |
   O   |
  /|\\  |
  / \\  |
       |
=========
""",
]

MAX_WRONG = 6


def display_word(word, guessed_letters):
    return " ".join(letter if letter in guessed_letters else "_" for letter in word)


def play_hangman():
    word = random.choice(WORDS)
    guessed_letters = set()
    wrong_guesses = 0

    print("\n==============================")
    print("   Welcome to Hangman!")
    print("==============================\n")

    while wrong_guesses < MAX_WRONG:
        print(HANGMAN_STAGES[wrong_guesses])
        print(f"Word: {display_word(word, guessed_letters)}")
        print(f"Wrong guesses left: {MAX_WRONG - wrong_guesses}")

        if guessed_letters:
            print(f"Letters guessed: {', '.join(sorted(guessed_letters))}")

        if "_" not in display_word(word, guessed_letters):
            print(f"\n✅  You WIN! The word was: '{word}'")
            return

        guess = input("\nGuess a letter: ").lower().strip()

        if len(guess) != 1 or not guess.isalpha():
            print("Please enter a single letter.")
            continue

        if guess in guessed_letters:
            print(f"You already guessed '{guess}'. Try a different letter.")
            continue

        guessed_letters.add(guess)

        if guess in word:
            print(f"✅  '{guess}' is in the word!")
        else:
            wrong_guesses += 1
            print(f"❌  '{guess}' is NOT in the word.")

    print(HANGMAN_STAGES[MAX_WRONG])
    print(f"\n💀  Game Over! The word was: '{word}'")


def main():
    while True:
        play_hangman()
        again = input("\nPlay again? (yes/no): ").lower().strip()
        if again not in ("yes", "y"):
            print("\nThanks for playing Hangman! Goodbye.")
            break


if __name__ == "__main__":
    main()
