RESPONSES = {
    ("hello", "hi", "hey"): "Hi there! How can I help you today?",
    ("how are you",): "I'm doing great, thanks for asking! How about you?",
    ("what is your name", "your name"): "I'm CodeBot, your friendly rule-based assistant!",
    ("what can you do", "help"): "I can answer basic questions! Try: hello, how are you, joke, python, bye.",
    ("time",): "I don't have a clock, but your device does! Check the corner of your screen.",
    ("bye", "goodbye", "see you"): "Goodbye! Have a great day!",
    ("thanks", "thank you"): "You're welcome! Is there anything else I can help with?",
    ("joke",): "Why do programmers prefer dark mode? Because light attracts bugs!",
    ("python",): "Python is an amazing language! Great choice for this internship.",
    ("codealpha",): "CodeAlpha is a great place to learn real-world Python skills!",
}

DEFAULT_RESPONSE = "Hmm, I'm not sure about that. Try asking something else!"


def get_response(user_input):
    user_input = user_input.lower().strip()

    for keywords, reply in RESPONSES.items():
        for keyword in keywords:
            if keyword in user_input:
                return reply

    return DEFAULT_RESPONSE


def chat():
    print("=" * 50)
    print("   CodeBot — Basic Chatbot (CodeAlpha Task 4)")
    print("=" * 50)
    print("\nCodeBot: Hello! I'm CodeBot. Type something to get started!")
    print("         (Type 'bye' to exit)\n")

    while True:
        user_input = input("You: ").strip()

        if not user_input:
            continue

        response = get_response(user_input)
        print(f"CodeBot: {response}\n")

        if any(word in user_input.lower() for word in ("bye", "goodbye", "see you")):
            break


if __name__ == "__main__":
    chat()
