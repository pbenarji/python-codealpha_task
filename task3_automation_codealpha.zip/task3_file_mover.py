import os
import shutil

SOURCE_FOLDER = "source_folder"
DEST_FOLDER = "JPG_Files"


def create_sample_files():
    os.makedirs(SOURCE_FOLDER, exist_ok=True)

    sample_files = [
        "photo1.jpg", "document.pdf", "vacation.jpg",
        "notes.txt", "beach.jpg", "report.docx",
        "selfie.jpg", "data.csv", "sunset.jpg", "readme.md"
    ]

    for filename in sample_files:
        filepath = os.path.join(SOURCE_FOLDER, filename)
        with open(filepath, "w") as f:
            f.write(f"Sample content for {filename}")

    print(f"Created {len(sample_files)} sample files in '{SOURCE_FOLDER}/'")


def move_jpg_files():
    os.makedirs(DEST_FOLDER, exist_ok=True)

    all_files = os.listdir(SOURCE_FOLDER)

    if not all_files:
        print("Source folder is empty. Nothing to move.")
        return

    moved = 0
    skipped = 0

    print(f"\nScanning '{SOURCE_FOLDER}/' for .jpg files...\n")

    for filename in all_files:
        if filename.lower().endswith(".jpg"):
            src = os.path.join(SOURCE_FOLDER, filename)
            dst = os.path.join(DEST_FOLDER, filename)
            shutil.move(src, dst)
            print(f"  MOVED   -> {filename}")
            moved += 1
        else:
            print(f"  SKIPPED -- {filename}")
            skipped += 1

    print(f"\nDone! Moved {moved} JPG file(s) to '{DEST_FOLDER}/'")
    print(f"Skipped {skipped} non-JPG file(s).")


def main():
    print("=" * 50)
    print("   File Mover (JPG Sorter) — CodeAlpha Task 3")
    print("=" * 50)

    create_sample_files()
    move_jpg_files()

    print(f"\nContents of '{DEST_FOLDER}/':")
    for f in os.listdir(DEST_FOLDER):
        print(f"  - {f}")


if __name__ == "__main__":
    main()
