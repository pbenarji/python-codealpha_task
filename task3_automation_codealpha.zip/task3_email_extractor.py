import re

INPUT_FILE = "sample_text.txt"
OUTPUT_FILE = "extracted_emails.txt"

SAMPLE_TEXT = """Contact our team at support@codealpha.tech or services@codealpha.tech.
For billing, email billing@company.org. Reach sales at john.doe@example.com.
You can also try info@website.net or hr@business.co.uk for other queries.
Invalid ones: notanemail, @nope.com, missing@, nodomain@
"""


def create_sample_file():
    with open(INPUT_FILE, "w") as f:
        f.write(SAMPLE_TEXT)
    print(f"Sample file '{INPUT_FILE}' created.")


def extract_emails(text):
    pattern = r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}"
    return re.findall(pattern, text)


def main():
    print("=" * 50)
    print("   Email Extractor — CodeAlpha Task 3")
    print("=" * 50)

    create_sample_file()

    with open(INPUT_FILE, "r") as f:
        text = f.read()

    print(f"\nReading from: '{INPUT_FILE}'")

    emails = extract_emails(text)

    if not emails:
        print("No email addresses found in the file.")
        return

    print(f"\nFound {len(emails)} email address(es):")
    for email in emails:
        print(f"  - {email}")

    with open(OUTPUT_FILE, "w") as f:
        for email in emails:
            f.write(email + "\n")

    print(f"\nEmails saved to '{OUTPUT_FILE}'.")


if __name__ == "__main__":
    main()
