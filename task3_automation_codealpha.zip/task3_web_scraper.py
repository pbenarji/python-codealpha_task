import requests
from html.parser import HTMLParser

TARGET_URL = "https://www.codealpha.tech"
OUTPUT_FILE = "scraped_title.txt"


class TitleParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.in_title = False
        self.title = ""

    def handle_starttag(self, tag, attrs):
        if tag.lower() == "title":
            self.in_title = True

    def handle_endtag(self, tag):
        if tag.lower() == "title":
            self.in_title = False

    def handle_data(self, data):
        if self.in_title:
            self.title += data.strip()


def scrape_title(url):
    headers = {"User-Agent": "Mozilla/5.0 (compatible; PythonScraper/1.0)"}

    print(f"Fetching: {url}")
    response = requests.get(url, headers=headers, timeout=10)
    response.raise_for_status()

    parser = TitleParser()
    parser.feed(response.text)

    return parser.title if parser.title else "No title found"


def save_result(url, title):
    with open(OUTPUT_FILE, "w") as f:
        f.write(f"URL   : {url}\n")
        f.write(f"Title : {title}\n")
        f.write(f"Status: 200 OK\n")

    print(f"Result saved to '{OUTPUT_FILE}'.")


def main():
    print("=" * 50)
    print("   Web Scraper — CodeAlpha Task 3")
    print("=" * 50)

    try:
        title = scrape_title(TARGET_URL)

        print(f"\nScraped title: \"{title}\"")

        save_result(TARGET_URL, title)

    except requests.exceptions.ConnectionError:
        print("\nError: Could not connect. Check your internet connection.")
    except requests.exceptions.HTTPError as e:
        print(f"\nHTTP Error: {e}")
    except Exception as e:
        print(f"\nUnexpected error: {e}")


if __name__ == "__main__":
    main()
